# FIRMA

## Ambasada Nieruchomości Sp. z o.o.

Biuro nieruchomości w Białymstoku. Pośrednictwo w sprzedaży, kupnie i wynajmie nieruchomości. Zespół: ~9 doradców + właścicielka (Magda).

**Biura:** ul. Piękna 2/2A, Białystok | ul. Św. Mikołaja 1/11, Białystok
**Godziny:** PN-PT 9:00-17:00
**Zasięg:** województwo podlaskie, mazowieckie, warmińsko-mazurskie
**Strona:** ambasada-nieruchomosci.pl
**Portale:** Otodom, Morizon, Gratka, Domiporta, Gethome

## Jak pracują doradcy

Każdy doradca prowadzi własnych klientów i transakcje od początku do końca. Typowy dzień to mieszanka: spotkania z klientami w terenie, pisanie ogłoszeń, obróbka zdjęć, wypełnianie dokumentów, wizyty w urzędach, telefony i maile. Nie ma stałego schematu, dzień układa się wokół bieżących transakcji i klientów.

Główne obszary pracy:

- **Pozyskiwanie nieruchomości:** cold calling do sprzedających (portal nbot), spotkania wycenowe, podpisywanie umów pośrednictwa
- **Przygotowanie oferty:** home staging, sesja zdjęciowa (aparat + żyrafka 360), obróbka zdjęć (Lightroom Classic: HDR, korekta kolorów, retusz), wizualizacje wnętrz (Freepik), krótkie filmiki i spacery wirtualne
- **Ogłoszenia:** pisanie opisów nieruchomości, wprowadzanie do VIRGO/Galactica, publikacja na portalach + grupy FB
- **Dopasowywanie ofert:** przeszukiwanie portali (Otodom, Morizon, Gratka) pod preferencje klientów kupujących. Ręczne, portal po portalu, 1-2h na klienta
- **Prezentacje:** spotkania na nieruchomościach, dni otwarte, rozmowa o okolicy, zaletach i wadach
- **Transakcje:** sprawdzanie stanu prawnego (akt notarialny, księga wieczysta), kontakt z notariuszem i doradcą finansowym, zbieranie zaświadczeń z urzędów
- **Formalności po transakcji:** przepisywanie mediów (PGE, gaz, wodociągi), protokoły zdawczo-odbiorcze, deklaracje podatkowe, wnioski do sądów i urzędów
- **Wyceny:** porównanie cen ofertowych (nbot) i transakcyjnych, konsultacje z zespołem przez Messenger, sprawdzanie planu ogólnego gminy na geoportalu

## Narzędzia w biurze

- **VIRGO** / **Galactica** - systemy CRM biura (baza ofert, klientów, transakcji, publikacja na portale)
- **Adobe Lightroom Classic** - obróbka zdjęć nieruchomości (HDR, korekcja, retusz)
- **Freepik** - wizualizacje wnętrz, filmiki, spacery wirtualne
- **nbot** - portal do wyszukiwania ofert sprzedaży (cold calling)
- **Geoportal / 1map.pl** - sprawdzanie planów zagospodarowania, przeznaczenia działek
- **Messenger** - główny kanał komunikacji w zespole (konsultacje, wyceny)
- **Portale ogłoszeniowe** - Otodom, Morizon, Gratka, Domiporta, Gethome
- **Grupy FB** - dodatkowy kanał publikacji ogłoszeń

## Co zajmuje najwięcej czasu

Rzeczy, przy których system może pomóc:

- **Ogłoszenia:** 1-2h na opis z wielokrotną redakcją. Główna frustracja: AI pisze w punktach, koloryzuje, brzmi sztucznie.
- **Dopasowywanie ofert kupującym:** ręczne przeszukiwanie wielu portali, 1-2h na klienta. Bardzo dużo czasu, trudno dobrać najlepsze oferty z całego rynku.
- **Dokumenty:** protokoły, pełnomocnictwa, wnioski, deklaracje, umowy. Kilka godzin na transakcję, formularze papierowe wypełniane ręcznie.
- **Obróbka zdjęć:** 10-40 zdjęć na nieruchomość, każde obrabiane osobno. Przy dużych nieruchomościach cały dzień.
- **Cold calling (powroty):** mentalne obciążenie, jak poprowadzić rozmowę z kimś, kto raz odmówił.
- **Formalności po transakcji:** przepisywanie mediów, wizyty osobiste w placówkach, cały dzień na jedną transakcję.

## Słownik firmowy

- **Oferta** - konkretna nieruchomość w portfolio biura
- **Namiar** - kontakt od potencjalnego klienta kupującego (uciekające namiary to znany problem)
- **Prezentacja** - pokazanie nieruchomości klientowi na żywo
- **Dni otwarte** - otwarte prezentacje nieruchomości dla wielu klientów naraz
- **Home staging** - przygotowanie wnętrza do sprzedaży (aranżacja, dekoracja)
- **Protokół zdawczo-odbiorczy** - dokument przekazania nieruchomości z odczytami liczników
- **Księga wieczysta** - rejestr stanu prawnego nieruchomości (właściciele, hipoteka, służebności)
- **Doradca finansowy** - zewnętrzny partner pomagający klientom uzyskać kredyt
- **Cold calling** - dzwonienie do osób z ogłoszeń sprzedaży w celu pozyskania do biura

## Kontekst dla ogłoszeń

Kiedy piszesz ogłoszenie nieruchomości dla Ambasady:

- Pisz płynnym tekstem, nie w punktach. Rozbudowane zdania, nie lista parametrów.
- Nie koloryzuj. "Piec na opał stały" to piec na opał stały, nie "element wiejskiego klimatu."
- Nie bądź sztucznie entuzjastyczny. Doradcy chcą brzmieć jak oni, nie jak generyczna formułka reklamowa.
- Okolicę opisuj konkretnie: nazwy ulic, odległości do szkół/sklepów/przystanków, charakter osiedla.
- Doradca zna okolicę lepiej niż ty. Kiedy podaje szczegóły lokalizacji, to są fakty.
- Mów o zaletach i wadach. Doradcy prezentują nieruchomości "po ludzku", nie tylko pozytywnie.
- Zdjęcia: biuro korzysta z profesjonalnych sesji foto, Freepika do wizualizacji, Lightrooma do obróbki.
