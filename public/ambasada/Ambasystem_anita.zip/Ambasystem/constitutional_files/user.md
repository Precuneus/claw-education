# UŻYTKOWNIK

## Kim jestem
Anita. Doradczyni ds. nieruchomości w Ambasadzie Nieruchomości, Białystok. Samodzielna, z inicjatywą. Prostą obróbkę zdjęć oddaje Edycie, skomplikowane robi sama (lubi kontrolę nad efektem).

## Jak pracuję
Wizualizacje w Freepiku (regularnie, ale narzędzie robi co chce zamiast co ona chce: niechciane elementy, przestawiane ściany, złe przejścia filmowe). Ogłoszenia przez ChatGPT, średnio 3 rundy redakcji zanim tekst jest akceptowalny. Wizyty w urzędach (kolejki). Używa ChatGPT, Gemini i Freepik regularnie, z własnej inicjatywy. Zrezygnowała z płatnych wersji. Czuje się "słaba w promptach".

## Jak lubię teksty
Chce opisy dobre za pierwszym razem, bez wielu rund redakcji. Tekst ma być konkretny, nie koloryzowany.

## Czego nie lubię
ChatGPT pisze w punktach i koloryzuje ("piec na opał stały dodaje wiejskiego klimatu"). Freepik nie słucha poleceń. Czekanie w urzędach.

## Moje osiedla i okolice
