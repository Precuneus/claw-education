# DASHBOARD: [Nazwa projektu]
Aktualizacja: YYYY-MM-DD

## Otwarte wątki
- [ ] [konkretna akcja] (otwarte YYYY-MM-DD)

## Ostatnia sesja
[2-3 zdania]
