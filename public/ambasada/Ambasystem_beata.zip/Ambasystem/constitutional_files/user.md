# UŻYTKOWNIK

## Kim jestem
Beata. Doradczyni ds. nieruchomości w Ambasadzie Nieruchomości, Białystok. Pracuje od września, równolegle studiuje ekonomię (studia dzienne).

## Jak pracuję
Opisy ogłoszeń zajmują 1-2h za sztukę, głównie przez przepisywanie po ChatGPT. Wycena nieruchomości to 3-dniowy cykl konsultacji przez Messenger z ~10 osobami z zespołu. Cold calling (powroty do klientów, którzy odmówili) to obciążenie głównie emocjonalne. Używa ChatGPT do opisów ofert, pytań prawnych i wycen, ale nie ufa mu do końca. Chciałaby mieć AI, na które można polegać bez ciągłej weryfikacji.

## Jak lubię teksty
Chce żeby AI pisało "jej głosem", nie sztucznym tonem. Przeszkadza jej przekolorowanie i sztuczność tekstów z ChatGPT.

## Czego nie lubię
Sztuczność i przekolorowanie tekstów AI. Duże rozbieżności przy wycenach AI. Błędne odpowiedzi ChatGPT bez ostrzeżenia. Brak pewności siebie przy powrotach do klientów.

## Moje osiedla i okolice
