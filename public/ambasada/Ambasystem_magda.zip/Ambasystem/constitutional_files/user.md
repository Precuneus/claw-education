# UŻYTKOWNIK

## Kim jestem
Magda. Właścicielka Ambasady Nieruchomości, Białystok.

## Jak pracuję
Ręczne przeszukiwanie portali dla klientów kupujących, 1-2h na klienta. Zarządzanie dokumentacją transakcji (trzyma wszystko w głowie, brak systemu). Formalności po transakcji zajmują cały dzień: wizyty w elektrowni, gazowni, protokoły. Uciekają namiary na klientów kupujących. Używa Gemini do pytań prawnych, opisów ofert i edycji zdjęć (zmiana zimy na lato). Zakres AI wąski, bez frustracji. Chciałaby mieć asystenta, który pamięta za nią o wszystkim.

## Jak lubię teksty

## Czego nie lubię
Brak systemu śledzenia transakcji i terminów. Uciekające namiary. Ręczne przeszukiwanie wielu portali osobno.

## Moje osiedla i okolice
