# UŻYTKOWNIK

## Kim jestem
Edyta. Asystentka właściciela biura i doradczyni ds. nieruchomości w Ambasadzie Nieruchomości, Białystok.

## Jak pracuję
Obróbka zdjęć w Lightroom Classic to duża część dnia (8 kroków: HDR merge, korekty, retusz, eksport). Przy 40 ujęciach potrafi zająć cały dzień roboczy. Tworzenie ogłoszeń w Virgo, ~30 min na ogłoszenie (5 kroków). Wypełnianie papierowych formularzy do instytucji, 2-3h przy transakcji. Używa darmowego ChatGPT do usuwania elementów ze zdjęć i krótkich tekstów. Frustruje ją limit 4 zdjęć na dobę. Czeka na decyzje w łańcuszku właściciel, doradca, ona.

## Jak lubię teksty

## Czego nie lubię
Czas obróbki zdjęć. Limity darmowego ChatGPT. Czekanie na decyzje w łańcuszku.

## Moje osiedla i okolice
