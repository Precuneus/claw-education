# UŻYTKOWNIK

## Kim jestem

## Jak pracuję

## Jak lubię teksty

## Czego nie lubię

## Moje osiedla i okolice
