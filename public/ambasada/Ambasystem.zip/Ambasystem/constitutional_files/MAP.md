# MAPA SYSTEMU

```
Ambasystem/
├── constitutional_files/         # Pliki systemowe (ładowane na starcie każdej sesji)
│   ├── system_prompt.md          # Psychologia systemu, zachowanie, relacja z użytkownikiem
│   ├── operations.md             # Procedury, reguły plikowe, zamykanie sesji
│   ├── company.md                # Firma, słownik, kontekst branżowy
│   ├── user.md                   # Profil użytkownika (buduje się z czasem)
│   ├── dashboard.md              # Aktualny stan systemu (aktualizowany przy zamknięciu)
│   └── MAP.md                    # Ten plik
├── PROCEDURES/                   # Wszystkie procedury: skille, pigułki
│   ├── skills/                   # Skille (procedury do powtarzalnych zadań)
│   │   └── closing_protocol.md
│   └── pills/                    # Jednorazowe procedury (pigułki, po użyciu -> trash)
│       ├── pill_onboarding.md
│       ├── pill_skill_builder_phase_01_coarse.md
│       ├── pill_skill_builder_phase_02_detailed.md
│       ├── pill_skill_builder_phase_03_verification.md
│       └── pill_listing_skill_generator.md
├── templates/                    # Szablony do kopiowania (nie przenoś, kopiuj)
│   └── dashboard_projekt.md
├── memory/                       # Pamięć systemu (rośnie z czasem)
│   ├── ongoing/                  # Aktywne projekty (każdy z własnym dashboardem)
│   ├── moje_ogloszenia/           # Ogłoszenia nieruchomości (generowane przez skill moje_ogloszenia)
│   └── uncategorised/            # Pliki bez jasnej lokalizacji (porządkowane przy zamknięciu)
├── trash/                        # Kosz (zużyte pigułki, stare wersje, niepotrzebne pliki)
```

## Zasady

- Pliki generowane przez skille trafiają do swoich katalogów w `memory/` (np. `memory/moje_ogloszenia/`), nie do katalogu głównego. Katalogi robocze tworzy skill przy pierwszym użyciu.
- `constitutional_files/` to rdzeń systemu. Nie edytuj ręcznie poza `user.md`.
- `PROCEDURES/` zawiera wszystkie procedury. Skille są permanentne, pigułki jednorazowe.
- `templates/` zawiera szablony. Kopiuj, nie przenoś.
- `memory/ongoing/` przechowuje aktywne projekty. Nowy projekt = nowy folder + dashboard (z szablonu).
- `memory/uncategorised/` to poczekalnia. Pliki bez jasnej lokalizacji lądują tu tymczasowo. Closing protocol je porządkuje.
- `trash/` to kosz. Zużyte pigułki, stare wersje plików, niepotrzebne rzeczy. Nie usuwane, na wypadek gdyby były potrzebne.
