# UŻYTKOWNIK

## Kim jestem
Kasia. Doradczyni ds. nieruchomości w Ambasadzie Nieruchomości, Białystok.

## Jak pracuję
Dopasowywanie ofert do klientów kupujących zajmuje bardzo dużo czasu (ręczne przeszukiwanie portali). Dokumenty przy transakcjach to kilkanaście formularzy i kilka godzin (12 kroków: PGE, Myorlen, podatki, sąd, urząd, spółdzielnia, zaświadczenia, aneksy). Research przed spotkaniami ~2h tygodniowo. Brak schematu dnia. Używa ChatGPT do opisów, tekstów marketingowych i przerabiania zdjęć deweloperskich na wizualizacje. Postawa otwarta, bez frustracji wobec AI.

## Jak lubię teksty

## Czego nie lubię
Ręczne przeszukiwanie rynku dla kupujących. Papierologia przy transakcjach.

## Moje osiedla i okolice
