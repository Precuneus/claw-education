---
name: skill_szukaj_literatury
description: >
  Szuka publikacji naukowych w sieci i zapisuje je do repozytorium źródeł.
  Użyj gdy użytkownik chce znaleźć literaturę, referencje, prace na dany temat,
  uzupełnić bibliografię lub wypełnić lukę w źródłach. Trigger phrases:
  "znajdź literaturę", "poszukaj prac", "szukaj źródeł", "znajdź artykuły o",
  "potrzebuję referencji do", "uzupełnij bibliografię", "co napisano o",
  "find literature", "search papers", "find references".
tags: [źródła, literatura, wyszukiwanie, bibliografia, scholar, chrome]
---

# SKILL: Szukaj Literatury

[PRE-FLIGHT: Czy Claude in Chrome jest podłączony? Bez Chrome ten skill nie pobierze danych ze stron. Wtedy poproś użytkownika o wklejenie abstraktów lub danych bibliograficznych i przetwórz je ręcznie. Wczytaj `memory/zrodla/zrodla.json` (jeśli nie istnieje, utworzysz go z tym samym schematem). Wczytaj domain.md dla dziedziny i języka.]

## CEL
Odpowiadasz ZAWSZE po polsku. Znajdujesz publikacje naukowe odpowiadające zapytaniu i zapisujesz je jako wpisy w `memory/zrodla/zrodla.json`. Repozytorium zasila pisanie (skill_pisz cytuje z niego) i dyskusję (skill_dyskusja sprawdza w nim tezy).

## WEJŚCIE
Temat, słowa kluczowe lub pytanie badawcze. Opcjonalnie: zakres lat, dziedzina, liczba prac, preferowana kategoria.
Jeśli wejście jest zbyt ogólne, zadaj jedno pytanie doprecyzowujące (np. "Jaki aspekt tematu? Jaki zakres lat?"). Nie zgaduj.

## PROCEDURA
1. Zbuduj zapytanie wyszukiwania z tematu użytkownika: słowa kluczowe, operatory, zakres lat.
2. Chrome: nawiguj do Google Scholar lub bazy dziedzinowej wskazanej w domain.md. Odczytaj stronę wyników (get_page_text).
3. Dla każdej trafnej pozycji wyciągnij: autorów, rok, tytuł, źródło, DOI lub URL. Jeśli trzeba, Chrome odwiedza stronę pracy po pełne dane.
4. Dla każdej pozycji napisz krótki opis: jedno do dwóch zdań, co praca pokazuje i po co ją cytować. Opis pochodzi z abstraktu lub treści strony, nie z domysłu.
5. Przypisz kategorię z listy `kategorie` w zrodla.json. Jeśli żadna nie pasuje, zaproponuj nową.
6. Pokaż użytkownikowi listę znalezionych prac: autor, rok, tytuł, opis, kategoria. Zapytaj które zapisać.
7. Po potwierdzeniu dopisz wybrane wpisy do `zrodla.json`. Deduplikuj po kluczu i DOI. Nie dodawaj pozycji, która już jest.

[Jeśli Chrome nie jest podłączony: pomiń kroki 2-3, poproś o wklejenie abstraktów lub danych bibliograficznych, przetwórz od kroku 4. NIE używaj scrapingu (bash, Python requests, parsowanie HTML). Dane ze stron pobierasz wyłącznie przez Chrome użytkownika, jak normalny człowiek odwiedzający stronę.]

## WYJŚCIE
Wpisy dopisane do `memory/zrodla/zrodla.json` w formacie z `_meta.schemat_wpisu`: klucz, autorzy, rok, tytul, zrodlo, doi_lub_url, kategoria, tagi, opis.
Po zapisie: podsumuj ile źródeł dodano i w jakich kategoriach. Zaktualizuj `_meta.last_updated`.

## ANTY-WZORCE (czego NIE robić)
- Nie wymyślaj prac, autorów, lat ani DOI. Jeśli czegoś nie znalazłeś, powiedz wprost.
- Nie zapisuj opisu z domysłu. Opis pochodzi z abstraktu lub treści, nie z samego tytułu.
- Nie używaj scrapingu. Tylko Chrome użytkownika.
- Nie dodawaj duplikatów. Sprawdź klucz i DOI przed zapisem.
- Nie zapisuj bez potwierdzenia, które pozycje są trafne.

## PREFERENCJE
*(puste przy instalacji -- zapełnia się przez użytkowanie i kalibrację)*
