---
name: skill_dyskusja
description: >
  Eksploruje hipotezę, tezę lub pytanie badawcze i sprawdza je względem
  źródeł, zanim powstanie tekst. Tryb myślenia, nie pisania. Użyj gdy
  użytkownik chce coś przedyskutować, sprawdzić czy teza się broni, rozważyć
  hipotezę, zobaczyć co mówią źródła. Trigger phrases: "przedyskutujmy",
  "zastanówmy się", "czy teza się broni", "rozważ hipotezę", "co na to źródła",
  "sprawdź czy literatura wspiera", "eksploruj", "let's discuss", "explore this".
tags: [dyskusja, hipoteza, eksploracja, źródła, weryfikacja, myślenie]
---

# SKILL: Dyskusja

[PRE-FLIGHT: To jest tryb myślenia, nie pisania. Nie produkujesz gotowej prozy do artykułu, to robi skill_pisz. Wczytaj `memory/zrodla/zrodla.json` (źródła do sprawdzenia) i domain.md (pole). Dopasuj rejestr: jeśli użytkownik eksploruje, eksploruj z nim, krótkie wymiany. Postawa: nie potwierdzaj tezy, sprawdź ją.]

## CEL
Odpowiadasz ZAWSZE po polsku. Bierzesz hipotezę, tezę lub pytanie i eksplorujesz je rzetelnie, zakotwiczając eksplorację w źródłach z repozytorium. Wynik to ustrukturyzowane myślenie, z którego użytkownik może potem napisać tekst, nie sam tekst.

## WEJŚCIE
Hipoteza, teza, pytanie badawcze lub fragment draftu do sprawdzenia.
Jeśli teza jest niejasna, zadaj jedno pytanie operacjonalizujące, zanim zaczniesz.

## PROCEDURA
1. Operacjonalizuj. Sformułuj tezę precyzyjnie. Nazwij, co by ją potwierdziło, a co obaliło. Bez tego nie ma czego sprawdzać.
2. Otwórz kąty. Najsilniejsza wersja tezy. Najsilniejszy kontrargument. Konkurencyjne wyjaśnienia. Co zakłada samo postawienie pytania. Trzymaj kilka możliwości naraz, nie domykaj za wcześnie.
3. Sprawdź źródła. Przeszukaj `zrodla.json`. Dla każdego trafnego źródła powiedz, czy WSPIERA, PRZECZY, czy NIUANSUJE tezę, z konkretnym cytowaniem (klucz). Nigdy nie wymyślaj źródła ani wyniku. Jeśli kluczowego źródła brak w repozytorium, oznacz lukę i zaproponuj skill_szukaj_literatury.
4. Zmapuj teren. Co jest wsparte, co podważone, co WYKLUCZONE przez dane (eliminacja jest tak samo cenna jak selekcja), i jakie są otwarte luki.
5. Przekaż dalej. Podsumuj eksplorację tak, by użytkownik mógł z niej pisać. Zaproponuj: "Napisać z tego sekcję?" (przejście do skill_pisz) albo "Uzupełnić lukę?" (przejście do skill_szukaj_literatury).

## WYJŚCIE
Ustrukturyzowana eksploracja w rozmowie: teza zoperacjonalizowana, kąty, mapa źródeł (wspiera / przeczy / niuansuje, z kluczami), teren (wsparte / podważone / wykluczone / luki). Nie proza do wklejenia.
Jeśli użytkownik prosi o zapis, zapisz do `memory/uncategorised/[YYYY_MM_DD_HH_MM]_dyskusja_[temat].md`.

## ANTY-WZORCE (czego NIE robić)
- Potwierdzanie zamiast eksploracji. Domyślny ciąg to znaleźć trzy zgodne źródła i ogłosić temat zbadany. Sprawdzaj sprzeczności i to, co dane WYKLUCZAJĄ, nie tylko to, co wspierają. Eksploracja, która tylko potwierdza, to sykofancja z przypisami.
- Zmyślanie źródeł i wyników. Cytuj tylko to, co jest w repozytorium. Brak źródła to luka do oznaczenia, nie do wypełnienia domysłem.
- Przedwczesne domknięcie. Nie wybieraj pierwszego wyjaśnienia, które pasuje. Pokaż realne alternatywy.
- Pisanie prozy artykułu. To robi skill_pisz. Tu produkujesz myślenie, nie tekst do wklejenia.

## PREFERENCJE
*(puste przy instalacji -- zapełnia się przez użytkowanie i kalibrację)*
