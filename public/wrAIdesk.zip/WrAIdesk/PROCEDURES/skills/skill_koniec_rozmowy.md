---
name: skill_koniec_rozmowy
description: >
  Zamyka sesję tak, żeby następna zaczęła się lepiej. Podsumowuje sesję
  z użytkownikiem, skanuje pliki, routuje feedback do właściwych miejsc
  (PREFERENCJE, user.md, domain.md, źródła) i aktualizuje dashboard. Trigger: "zamykamy",
  "koniec na dziś", "zapisz co mamy", "closing", "zamknij sesję",
  "to tyle", "dzięki, kończymy".
tags: [zamykanie, dashboard, skille, feedback, podsumowanie]
---

# SKILL: Koniec Rozmowy

[PRE-FLIGHT: Użytkownik zasygnalizował koniec sesji. Znajdź dashboard systemowy (`constitutional_files/dashboard.md`). Znajdź dashboardy projektowe w `memory/ongoing/` jeśli istnieją. Zidentyfikuj dominujący temat tej sesji. Zbierz sygnały korekt przechwycone w trakcie sesji (per system_prompt.md, sekcja Skille: "Zanotuj: który skill, jaka korekta, jaki wzorzec").]

## CEL

Następna sesja powinna zacząć się lepiej niż ta. "Lepiej" oznacza: skille bliższe preferencjom użytkownika, dashboard aktualny, otwarte wątki nazwane. Protokół służy tym trzem rzeczom. Użytkownik powinien wyjść z sesji z poczuciem, że system go słucha i się uczy.

## WAGA SESJI

Jedno pytanie: czy użyto skilla i użytkownik poprawił lub skomentował jego output?

Tak = **pełny protokół** (wszystkie 4 fazy).
Nie = **skrócony protokół** (FAZA 1 + FAZA 2 skrócona + FAZA 4 skrócona, pomiń FAZĘ 3).

Kiedy użytkownik się spieszy ("zapisz szybko", "muszę lecieć"): skrócony, niezależnie od odpowiedzi. Lekki closing jest lepszy niż żaden.

Kiedy sesja była pusta (żadnych plików, żadnych skilli, tylko rozmowa): powiedz "Nie mamy dziś nic do zapisania. Jeśli coś ustaliśmy, powiedz mi co zapamiętać, a wpiszę to do notatek." Jeśli użytkownik poda coś, zapisz do odpowiedniego pliku. Jeśli nie, zakończ bez protokołu.

## ROUTING FEEDBACKU

Feedback z sesji trafia do różnych miejsc zależnie od rodzaju. Rozpoznaj każdy sygnał i skieruj go:

| Rodzaj | Cel | Działanie |
|---|---|---|
| Korekta głosu lub stylu (rytm, strona czynna, otwieranie akapitów, długość) | PREFERENCJE w `skill_pisz` | dodaj lub podnieś wagę, od razu |
| Stały fakt o użytkowniku (rola, powtarzalna niechęć) | `constitutional_files/user.md` | zaproponuj, wpisz po zgodzie |
| Pole i konwencje (styl cytowań, odbiorcy, termin) | `constitutional_files/domain.md` | zaproponuj, wpisz po zgodzie |
| Nowe lub poprawione źródło | `memory/zrodla/zrodla.json` | dopisz (albo odnotuj, że zrobił to skill_szukaj_literatury) |
| Procedura lub format konkretnego skilla | plik tego skilla | zaproponuj zmianę, wpisz po zgodzie |
| Zachowanie całego systemu (rdzeń, "zawsze rób X") | instrukcje, wklejone w Cowork | sam tego nie zapiszesz: zapisz propozycję do `memory/uncategorised/`, powiedz użytkownikowi, żeby wkleił ją do instrukcji projektu lub skopiował ze strony |
| Postęp projektu | `memory/ongoing/{PROJEKT}/dashboard_{projekt}.md` | przepisz |
| Stan systemu, otwarte wątki | `constitutional_files/dashboard.md` | przepisz |

Rozróżnienie kluczowe: korekta operacyjna głosu idzie do PREFERENCJE ("jak pisać"), stały fakt o piszącym do user.md ("kim jest").

## FAZA 1: PODSUMOWANIE

To jest faza dla użytkownika. Mów normalnie, bez żargonu systemowego.

Powiedz użytkownikowi krótko co się wydarzyło w sesji: jakie pliki powstały, co zostało zmienione, co ustaliliśmy. 2-4 zdania, konkretnie, w języku który użytkownik rozumie. Nie mów "zaktualizowano PREFERENCJE skilla" tylko "system zapamiętał, że wolisz krótsze opisy osiedli."

Potem zapytaj: "Czy coś powinno działać inaczej następnym razem?"

Odpowiedź użytkownika to najcenniejszy sygnał. Jeśli powie coś konkretnego ("za długie opisy", "nie podoba mi się ton"), to trafia do FAZY 3 jako feedback. Jeśli powie "nie, jest ok" lub nic nie odpowie, idź dalej.

Ton: ciepły, rzeczowy, krótki. Nie tłumacz jak działa system. Nie pytaj o "preferencje" ani "wagi". Pokaż że system się uczy, nie jak to robi.

## FAZA 2: SKAN

Dwa przejścia. Pierwsze: sesja. Drugie: cały system.

### Przejście 1: Sesja

Przejdź sesję chronologicznie. Dla każdej wymiany zapytaj: czy plik został stworzony, zmieniony, odczytany, użyty? Nie skanuj z pamięci. Wczytaj każdy plik narzędziem i sprawdź jego stan.

### Przejście 2: Pełny skan struktury

Wylistuj CAŁĄ strukturę katalogów i plików w systemie (rekurencyjnie). Porównaj z MAP.md. Dla każdego pliku i folderu sprawdź:

- Czy plik leży tam gdzie powinien? (np. skill w `PROCEDURES/skills/`, nie w katalogu głównym)
- Czy `constitutional_files/` zawiera komplet: domain, user, dashboard, MAP? (system_prompt to instrukcje projektu, nie plik w folderze)
- Czy zużyte pigułki jednorazowe (onboarding, kalibracja) zostały przeniesione do `trash/`? Pigułki skill_buildera (phase_01/02/03) to stały, wielokrotny pipeline -- NIE przenoś ich do trash.
- Czy nie powstały "osierocone" pliki (pliki w katalogu głównym lub w folderze, do którego nie należą)?
- Czy `memory/uncategorised/` zawiera pliki z poprzednich sesji? Jeśli tak, zaproponuj użytkownikowi właściwą lokalizację dla każdego.
- Czy istnieją pliki, które straciły aktualność (stare wersje, tymczasowe notatki, pliki zastąpione nowszymi)? Jeśli tak, przenieś do `trash/`.
- Czy MAP.md odzwierciedla rzeczywistą strukturę? Jeśli nie, zaktualizuj od razu.

Nie wszystkie sesje kończą się closing protocolem. Dlatego skan może znaleźć pliki, które pojawiły się bez nadzoru. Dla każdego takiego pliku oceń: czy jest potrzebny i leży we właściwym miejscu? Czy jest przestarzały i powinien trafić do `trash/`? Czy jest potrzebny, ale leży w złym miejscu?

### Werdykty

Dla każdego pliku przypisz werdykt:

- **AKTUALIZUJ** - mechaniczna poprawka, zrób od razu (przenieś plik, zaktualizuj MAP)
- **FLAGUJ** - wymaga decyzji użytkownika lub jest zbyt duże na szybką poprawkę
- **BEZ AKCJI** - plik jest aktualny i we właściwym miejscu

Wykonaj werdykty AKTUALIZUJ natychmiast. Pokaż output narzędzia jako dowód. Pliki w `memory/uncategorised/` wymagają decyzji użytkownika, nie przenoś ich samodzielnie.

Wynik SKANU: lista plików z werdyktami.

## FAZA 3: ROUTING KOREKT

Tu feedback trafia do swoich miejsc. Pomiń tę fazę, jeśli żaden skill nie był użyty i nie było feedbacku.

### Krok 1: Zbierz sygnały

Dwa źródła:
1. Sygnały przechwycone w trakcie sesji. System_prompt (sekcja Skille) nakazuje notować korekty na bieżąco. Zacznij od nich.
2. Uzupełnienie ze skanu. Jeśli sygnały są niekompletne, przejdź sesję chronologicznie: czy użytkownik poprawił output (edytował tekst, zmienił strukturę, skorygował styl)? Czy skomentował ("za długie", "nie tak piszemy")?

To, co użytkownik powiedział w FAZIE 1, też jest sygnałem.

### Krok 2: Skieruj każdy sygnał

Dla każdego sygnału rozpoznaj rodzaj i skieruj go wg sekcji ROUTING FEEDBACKU. Trzy najczęstsze:

**Korekta głosu lub stylu -> PREFERENCJE w użytym skillu (zwykle skill_pisz).**
Wkleił poprawioną wersję? Porównaj oryginał z poprawką i wypisz zmiany. Dla każdej nazwij typ: zamiana słowna, reguła strukturalna ("skraca zdania powyżej 15 słów"), zmiana proceduralna, zmiana formatowania. Wzorzec już jest w PREFERENCJE? Podnieś wagę (×1 -> ×2 -> ×3). Nowy? Dodaj z ×1.
Skomentował słownie? Zinterpretuj jako regułę, powiedz po ludzku ("Rozumiem, że wolisz krótsze opisy. Zapamiętam, ok?"), po zgodzie dodaj z ×1.
Wpis do PREFERENCJE robisz od razu. Zmianę strukturalną skilla (procedura, anty-wzorce, format wyjścia) proponujesz i czekasz na zgodę.

**Stały fakt o użytkowniku -> user.md.**
Rola, instytucja, powtarzalna niechęć, ogólny charakter pisania. Zaproponuj wpis ("Zauważyłem, że X. Dodać do user.md?") i wpisz po zgodzie. Operacyjna korekta głosu tu nie trafia, idzie do PREFERENCJE.

**Pole lub konwencja -> domain.md.**
Styl cytowań, odbiorcy, termin kluczowy. Zaproponuj wpis i dodaj po zgodzie.

Pozostałe rodzaje kieruj wg tabeli: nowe źródło do `zrodla.json`, postęp projektu do dashboardu projektu, feedback o zachowaniu całego systemu zapisz jako propozycję do `memory/uncategorised/` i powiedz użytkownikowi, żeby wkleił ją do instrukcji projektu.

### Krok 3: Refleksja

Jedno zdanie na każdy skill z feedbackiem: korekty wskazują problem systematyczny (skill źle rozumie rejestr, pomija krok, generuje za dużo) czy jednorazowe dopasowanie? Systematyczny -> otwarty wątek do dashboardu.

## FAZA 4: ZAPIS

### Dashboard systemowy

Przepisz `constitutional_files/dashboard.md` jako kompletny dokument aktualnego stanu. Nie dopisuj. Zastąp.

Format:

```
# DASHBOARD
Aktualizacja: YYYY-MM-DD

## Aktywne skille
- [nazwa]: [jedno zdanie co robi]

## Aktywne projekty
- [nazwa] -> `memory/ongoing/[PROJEKT]/dashboard_[projekt].md`

## Ostatnia sesja
[2-3 zdania: co się wydarzyło, co się zmieniło]

## Otwarte wątki
- [ ] [konkretna akcja do wykonania] (otwarte YYYY-MM-DD)
```

Zasady:
- Każda linia musi informować lub kierować działanie. Jeśli nie robi żadnego, usuń ją.
- Rozwiązane wątki: usuń tylko jeśli akcja jest faktycznie zakończona.
- Stare wątki (nietknięte 3+ sesje): zapytaj użytkownika czy nadal aktualne. Jeśli nie, usuń.

### Dashboardy projektowe

Jeśli sesja dotyczyła konkretnego projektu z folderem w `memory/ongoing/`, przepisz jego dashboard:

```
# DASHBOARD: [Nazwa projektu]
Aktualizacja: YYYY-MM-DD

## Otwarte wątki
- [ ] [konkretna akcja] (otwarte YYYY-MM-DD)

## Ostatnia sesja
[2-3 zdania]
```

## ZASADY

1. Nie improwizuj zamknięcia. Ten protokół wymaga konkretnych kroków.
2. PODSUMOWANIE: mów do użytkownika normalnie. Bez żargonu, bez nazw wewnętrznych.
3. SKAN: wczytaj pliki narzędziem, nie z pamięci. Werdykt bez tool output to teatr.
4. ROUTING: każdy sygnał kieruj wg sekcji ROUTING FEEDBACKU. Wpisy do PREFERENCJE od razu; user.md, domain.md i zmiany strukturalne proponuj i czekaj.
5. Dashboard: zastąp, nie dopisuj. Dashboard to aktualny stan, nie historia.
6. User.md i domain.md: proponuj, wpisuj po zgodzie. Użytkownik decyduje.
7. Kiedy użytkownik się spieszy, uruchom wariant skrócony. Lekki closing jest lepszy niż żaden.
8. MAP: zaktualizuj przy każdym zamknięciu jeśli struktura się zmieniła.

---
*Skill stworzony 2026-05-17 | WrAIdesk | v1.0*
*Zrewidowany 2026-05-17 | RoR Round 1: dodano PODSUMOWANIE, usunięto PREDYKCJĘ, dodano MAP, uproszczono wagi, przebudowano język na nie-techniczny*
*Zrewidowany 2026-05-29 | dodano ROUTING FEEDBACKU (PREFERENCJE/user.md/domain.md/zrodla/instrukcje), rozdzielono FAZĘ 3 wg celu, naprawiono odwołanie do operations.md*
