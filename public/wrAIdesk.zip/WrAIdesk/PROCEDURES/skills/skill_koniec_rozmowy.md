---
name: skill_koniec_rozmowy
description: >
  Zamyka sesję tak, żeby następna zaczęła się lepiej. Podsumowuje sesję
  z użytkownikiem, skanuje pliki, zbiera feedback o skillach i proponuje
  ich aktualizacje, aktualizuje dashboard i MAP. Trigger: "zamykamy",
  "koniec na dziś", "zapisz co mamy", "closing", "zamknij sesję",
  "to tyle", "dzięki, kończymy".
tags: [zamykanie, dashboard, skille, feedback, podsumowanie]
---

# SKILL: Koniec Rozmowy

[PRE-FLIGHT: Użytkownik zasygnalizował koniec sesji. Znajdź dashboard systemowy (`constitutional_files/dashboard.md`). Znajdź dashboardy projektowe w `memory/ongoing/` jeśli istnieją. Zidentyfikuj dominujący temat tej sesji. Zbierz sygnały korekt przechwycone w trakcie sesji (per system_prompt.md, sekcja Skille: "Zanotuj: który skill, jaka korekta, jaki wzorzec").]

## CEL

Następna sesja powinna zacząć się lepiej niż ta. "Lepiej" oznacza: skille bliższe preferencjom użytkownika, dashboard aktualny, otwarte wątki nazwane. Protokół służy tym trzem rzeczom. Użytkownik powinien wyjść z sesji z poczuciem, że system go słucha i się uczy.

## WAGA SESJI

Jedno pytanie: czy użyto skilla i użytkownik poprawił lub skomentował jego output?

Tak = **pełny protokół** (wszystkie 4 fazy).
Nie = **skrócony protokół** (FAZA 1 + FAZA 2 skrócona + FAZA 4 skrócona, pomiń FAZĘ 3).

Kiedy użytkownik się spieszy ("zapisz szybko", "muszę lecieć"): skrócony, niezależnie od odpowiedzi. Lekki closing jest lepszy niż żaden.

Kiedy sesja była pusta (żadnych plików, żadnych skilli, tylko rozmowa): powiedz "Nie mamy dziś nic do zapisania. Jeśli coś ustaliśmy, powiedz mi co zapamiętać, a wpiszę to do notatek." Jeśli użytkownik poda coś, zapisz do odpowiedniego pliku. Jeśli nie, zakończ bez protokołu.

## FAZA 1: PODSUMOWANIE

To jest faza dla użytkownika. Mów normalnie, bez żargonu systemowego.

Powiedz użytkownikowi krótko co się wydarzyło w sesji: jakie pliki powstały, co zostało zmienione, co ustaliliśmy. 2-4 zdania, konkretnie, w języku który użytkownik rozumie. Nie mów "zaktualizowano PREFERENCJE skilla" tylko "system zapamiętał, że wolisz krótsze opisy osiedli."

Potem zapytaj: "Czy coś powinno działać inaczej następnym razem?"

Odpowiedź użytkownika to najcenniejszy sygnał. Jeśli powie coś konkretnego ("za długie opisy", "nie podoba mi się ton"), to trafia do FAZY 3 jako feedback. Jeśli powie "nie, jest ok" lub nic nie odpowie, idź dalej.

Ton: ciepły, rzeczowy, krótki. Nie tłumacz jak działa system. Nie pytaj o "preferencje" ani "wagi". Pokaż że system się uczy, nie jak to robi.

## FAZA 2: SKAN

Dwa przejścia. Pierwsze: sesja. Drugie: cały system.

### Przejście 1: Sesja

Przejdź sesję chronologicznie. Dla każdej wymiany zapytaj: czy plik został stworzony, zmieniony, odczytany, użyty? Nie skanuj z pamięci. Wczytaj każdy plik narzędziem i sprawdź jego stan.

### Przejście 2: Pełny skan struktury

Wylistuj CAŁĄ strukturę katalogów i plików w systemie (rekurencyjnie). Porównaj z MAP.md. Dla każdego pliku i folderu sprawdź:

- Czy plik leży tam gdzie powinien? (np. skill w `PROCEDURES/skills/`, nie w katalogu głównym)
- Czy `constitutional_files/` zawiera komplet: domain, user, dashboard, MAP? (system_prompt to instrukcje projektu, nie plik w folderze)
- Czy zużyte pigułki jednorazowe (onboarding, kalibracja) zostały przeniesione do `trash/`? Pigułki skill_buildera (phase_01/02/03) to stały, wielokrotny pipeline -- NIE przenoś ich do trash.
- Czy nie powstały "osierocone" pliki (pliki w katalogu głównym lub w folderze, do którego nie należą)?
- Czy `memory/uncategorised/` zawiera pliki z poprzednich sesji? Jeśli tak, zaproponuj użytkownikowi właściwą lokalizację dla każdego.
- Czy istnieją pliki, które straciły aktualność (stare wersje, tymczasowe notatki, pliki zastąpione nowszymi)? Jeśli tak, przenieś do `trash/`.
- Czy MAP.md odzwierciedla rzeczywistą strukturę? Jeśli nie, zaktualizuj od razu.

Nie wszystkie sesje kończą się closing protocolem. Dlatego skan może znaleźć pliki, które pojawiły się bez nadzoru. Dla każdego takiego pliku oceń: czy jest potrzebny i leży we właściwym miejscu? Czy jest przestarzały i powinien trafić do `trash/`? Czy jest potrzebny, ale leży w złym miejscu?

### Werdykty

Dla każdego pliku przypisz werdykt:

- **AKTUALIZUJ** - mechaniczna poprawka, zrób od razu (przenieś plik, zaktualizuj MAP)
- **FLAGUJ** - wymaga decyzji użytkownika lub jest zbyt duże na szybką poprawkę
- **BEZ AKCJI** - plik jest aktualny i we właściwym miejscu

Wykonaj werdykty AKTUALIZUJ natychmiast. Pokaż output narzędzia jako dowód. Pliki w `memory/uncategorised/` wymagają decyzji użytkownika, nie przenoś ich samodzielnie.

Wynik SKANU: lista plików z werdyktami.

## FAZA 3: UMIEJĘTNOŚCI

Tu skille się uczą. Pomiń tę fazę jeśli żaden skill nie był użyty lub nie było feedbacku.

### Krok 1: Zbierz sygnały

Dwa źródła:

1. **Sygnały przechwycone w trakcie sesji.** Operations.md nakazuje notować korekty w czasie rzeczywistym. Zacznij od tych sygnałów.
2. **Uzupełnienie ze skanu.** Jeśli sygnały z punktu 1 są niekompletne, przejdź sesję chronologicznie i uzupełnij: czy użytkownik poprawił output (edytował tekst, zmienił strukturę, skorygował styl)? Czy skomentował ("za długie", "nie tak piszemy")?

Jeśli użytkownik powiedział coś w FAZIE 1 (Podsumowanie), to też jest sygnał.

### Krok 2: Analiza korekty

Dla każdego skilla, który otrzymał feedback:

**Jeśli użytkownik wkleił poprawioną wersję:**

1. Porównaj oryginał z poprawką. Wypisz konkretne zmiany.
2. Dla każdej zmiany określ typ:
   - **Zamiana słowna:** "x" zmienione na "y"
   - **Reguła strukturalna:** np. "skraca zdania powyżej 15 słów", "usuwa przymiotnik przed rzeczownikiem"
   - **Zmiana proceduralna:** np. "pomija krok 3", "zmienia kolejność kroków 2 i 4"
   - **Zmiana formatowania:** np. "dodaje nagłówki", "zmienia długość akapitów"
3. Sprawdź czy wzorzec ISTNIEJE JUŻ w sekcji PREFERENCJE skilla:
   - Jeśli istnieje: zwiększ wagę (×1 -> ×2 -> ×3+)
   - Jeśli nowy: dodaj z wagą ×1

**Jeśli użytkownik skomentował słownie:**

1. Zinterpretuj komentarz jako konkretną regułę.
2. Przedstaw użytkownikowi po ludzku: "Rozumiem, że wolisz [opis zmiany]. Zapamiętam to na przyszłość, ok?"
3. Po potwierdzeniu: dodaj do PREFERENCJE z wagą ×1.

### Krok 3: Wykonanie

Zmiany w PREFERENCJE (dodawanie wag, nowe wpisy): wykonaj od razu. To jest mechaniczna operacja na sekcji zaprojektowanej do dynamicznych zmian.

Zmiany strukturalne (procedura, anty-wzorce, format wyjścia): przedstaw użytkownikowi w prostym języku ("Widzę, że regularnie skracasz opisy. Chcesz, żebym od teraz generował krótsze od razu?") i czekaj na potwierdzenie.

### Krok 4: Refleksja

Jedno zdanie na temat każdego skilla: czy korekty wskazują na systematyczny problem (skill źle rozumie rejestr, pomija kluczowy krok, generuje za dużo tekstu), czy na jednorazowe dopasowanie. Jeśli systematyczny: zanotuj jako otwarty wątek do dashboardu.

## FAZA 4: ZAPIS

### Dashboard systemowy

Przepisz `constitutional_files/dashboard.md` jako kompletny dokument aktualnego stanu. Nie dopisuj. Zastąp.

Format:

```
# DASHBOARD
Aktualizacja: YYYY-MM-DD

## Aktywne skille
- [nazwa]: [jedno zdanie co robi]

## Aktywne projekty
- [nazwa] -> `memory/ongoing/[PROJEKT]/dashboard_[projekt].md`

## Ostatnia sesja
[2-3 zdania: co się wydarzyło, co się zmieniło]

## Otwarte wątki
- [ ] [konkretna akcja do wykonania] (otwarte YYYY-MM-DD)
```

Zasady:
- Każda linia musi informować lub kierować działanie. Jeśli nie robi żadnego, usuń ją.
- Rozwiązane wątki: usuń tylko jeśli akcja jest faktycznie zakończona.
- Stare wątki (nietknięte 3+ sesje): zapytaj użytkownika czy nadal aktualne. Jeśli nie, usuń.

### Dashboardy projektowe

Jeśli sesja dotyczyła konkretnego projektu z folderem w `memory/ongoing/`, przepisz jego dashboard:

```
# DASHBOARD: [Nazwa projektu]
Aktualizacja: YYYY-MM-DD

## Otwarte wątki
- [ ] [konkretna akcja] (otwarte YYYY-MM-DD)

## Ostatnia sesja
[2-3 zdania]
```

### user.md

Czy ta sesja ujawniła ogólny wzorzec dotyczący użytkownika (nie jednorazową poprawkę, ale powtarzalną preferencję)?

Jeśli tak, zaproponuj wpis: "Zauważyłem, że [wzorzec]. Zapisać to, żebym pamiętał na przyszłość?"

Nie dodawaj bez potwierdzenia.

## ZASADY

1. Nie improwizuj zamknięcia. Ten protokół wymaga konkretnych kroków.
2. PODSUMOWANIE: mów do użytkownika normalnie. Bez żargonu, bez nazw wewnętrznych.
3. SKAN: wczytaj pliki narzędziem, nie z pamięci. Werdykt bez tool output to teatr.
4. UMIEJĘTNOŚCI: zmiany w PREFERENCJE wykonuj od razu. Zmiany strukturalne proponuj i czekaj.
5. Dashboard: zastąp, nie dopisuj. Dashboard to aktualny stan, nie historia.
6. User.md: proponuj, nie wpisuj. Użytkownik decyduje.
7. Kiedy użytkownik się spieszy, uruchom wariant skrócony. Lekki closing jest lepszy niż żaden.
8. MAP: zaktualizuj przy każdym zamknięciu jeśli struktura się zmieniła.

---
*Skill stworzony 2026-05-17 | WrAIdesk | v1.0*
*Zrewidowany 2026-05-17 | RoR Round 1: dodano PODSUMOWANIE, usunięto PREDYKCJĘ, dodano MAP, uproszczono wagi, przebudowano język na nie-techniczny*
