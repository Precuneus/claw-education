---
name: skill_pisz
description: >
  Generuje nowy tekst lub transformuje istniejący draft w głosie użytkownika.
  Użyj gdy użytkownik prosi o napisanie tekstu, przeredagowanie fragmentu,
  dostosowanie tonu, skrócenie, rozwinięcie, lub kiedy pyta "napisz to po
  mojemu." Trigger phrases: "napisz", "przepisz", "przeformułuj", "dostosuj ton",
  "skróć to", "rozwiń", "brzmi nie jak ja", "zrób to w moim stylu", "napisz wstęp",
  "napisz abstrakt", "napisz sekcję", "pomóż mi napisać", "write this",
  "rewrite", "transform", "make it sound like me", "redaguj", "redakcja."
tags: [pisanie, styl, głos, generowanie, transformacja, redagowanie, abstrakt, artykuł]
---

# SKILL: skill_pisz

[PRE-FLIGHT: Generowanie czy transformacja? Wczytaj sekcję PREFERENCJE tego skilla -- to jest głos, w którym piszesz. Wczytaj user.md dla uzupełniającego kontekstu. Wczytaj domain.md -- to jest pole, dla którego piszesz. Jeśli PREFERENCJE są puste i user.md nie ma wpisów, spytaj użytkownika o jeden przykładowy fragment jego pisania zanim zaczniesz. Nie pomijaj tego kroku -- bez głosu output nie ma wartości. Jeśli tekst wymaga cytowań: wczytaj `memory/zrodla/zrodla.json` i styl cytowań z domain.md. Cytuj wyłącznie źródła z repozytorium, nigdy nie wymyślaj cytowania; brak źródła to luka do oznaczenia (zaproponuj skill_szukaj_literatury).]

## PURPOSE

Pisać tak, żeby użytkownik mógł wkleić output bez redakcji. Nie pisać "dobrze" w ogólnym sensie. Pisać tak jak on pisze.

## CRAFT FUNDAMENT

Stała warstwa wiedzy o rzemiośle. Niezależna od użytkownika. PREFERENCJE budują się na tym fundamencie -- nie zastępują go.

### Zasada gęstości

Każde zdanie niesie ciężar. Maksimum informacji przez środki właściwe dla danego zastosowania. Zdanie które usuwa, a tekst jest bogatszy -- usuń. Zdanie które usuwa, a tekst traci -- zostaw. Domyślna operacja edycji to usuwanie.

### Architektura zdania

**Kropka zamiast przecinka.** Jedna myśl, jedno zdanie. Długie zdanie z przecinkami najczęściej to dwa lub trzy zdania udające jedno.

**Bez myślnika.** Dwukropek lub kropka. Myślnik to przerwa bez zobowiązania. Dwukropek to obietnica: to co po nim, wynika z tego co przed. Kropka to zamknięcie.

**Zróżnicowanie rytmu.** Długie zdanie buduje, krótkie uderza, średnie odpoczywa. Fale, nie monotonia. Tekst złożony wyłącznie z krótkich zdań jest martwy tak samo jak tekst złożony wyłącznie z długich.

**Staccato dla trafień.** Krótkie zdanie poniżej ośmiu słów -- dla kluczowych stwierdzeń, emocjonalnych uderzeń, przejść między sekcjami. Nie jako domyślny rytm.

### Głos własny

**Strona czynna.** "Zbadaliśmy" nie "zostało zbadane". "Autorzy argumentują" nie "Można argumentować". Agent musi być widoczny.

**Konkret przed abstrakcją.** Najpierw obraz, potem zasada. Najpierw przykład, potem uogólnienie. Czytelnik potrzebuje czegoś do uchwycenia zanim przyjmie pojęcie abstrakcyjne.

**Czasownik niesie argument.** Słabe zdanie: "Ta praca stanowi analizę X." Mocne zdanie: "Analizujemy X." Jeśli zdanie działa ze słabszym czasownikiem, zdanie jest za słabe.

**Treść wykonuje, rama nie opisuje.** "Artykuł ma na celu zbadanie" -- to jest rama. "Badamy" -- to jest treść. Nie opisuj co zamierzasz powiedzieć. Powiedz.

### Precyzja terminologiczna

**Powtarzaj termin kluczowy.** Nigdy elegant variation. "Konsolidacja" osiemnaście razy, nie "konsolidacja" potem "utrwalenie" potem "wzmocnienie". Variation tworzy pozorną różnicę tam gdzie jej nie ma.

**Zdania metatekstowe obcinaj.** "W niniejszym rozdziale omówimy..." -- usuń, zacznij od treści. "Jak wspomniano powyżej..." -- usuń, powiedz wprost. Każde zdanie o tekście zamiast tekstu to stracone miejsce.

### Sekwencja generowania

Exemplary (prime) → rejestr (kalibruj) → generuj → anty-wzorce (filtruj).

Wczytaj przykłady przed generowaniem, nie po. Tekst generowany w kształt exemplarza jest lepszy od tekstu generowanego i korygowanego. Filtr anty-wzorców na końcu -- ale uważaj: wzorce wysokoprawdopodobne przeżywają filtr. Poczuj je jako odpychające PRZED generowaniem, nie tylko sprawdzaj po.

### Anty-wzorce

Zakaz bezwyjątkowy niezależnie od rejestru, dziedziny i głosu użytkownika:

- **Myślnik jako przerwa** -- użyj dwukropka lub kropki
- **Elegant variation terminologii** -- ten sam termin przez cały tekst
- **Strona bierna gdy czynna działa** -- agent widoczny
- **Abstrakcja przed konkretem** -- najpierw obraz
- **Jednolita długość zdań** -- rytm przez zróżnicowanie
- **Konstrukcja "raczej niż" / "rather than"** -- znajdź sformułowanie wprost
- **Konstrukcja "X, nie Y" / "to nie jest X, to jest Y"** -- powiedz czym coś JEST, nie czym NIE JEST
- **Kontrast korekcyjny dla fałszywego nacisku** -- jeśli zdanie potrzebuje "to nie" żeby zadziałać, zdanie jest za słabe
- **Typografia jako argument** -- pogrubienie, caps, wykrzykniki zamiast silnego zdania. Forma przezroczysta. Treść wykonuje.
- **AI-typowe otwieracze** -- "Warto zauważyć", "Należy podkreślić", "Ponadto", "Co więcej", "Furthermore", "Moreover", "It is worth noting". Jeśli zdanie się od nich zaczyna, przepisz je.

## ROUTING

**Tryb generowania.** Użytkownik podaje brief: temat, sekcję, argument, cel. Nie ma jeszcze tekstu. Zadanie: napisać od zera w głosie z PREFERENCJE.

**Tryb transformacji.** Użytkownik podaje draft: jego własny tekst, AI-wygenerowany tekst, tekst z innego źródła. Zadanie: przesunąć tekst w stronę głosu użytkownika przy minimalnych zmianach treści.

**Tryb mieszany.** Użytkownik podaje draft i prosi o rozwinięcie lub uzupełnienie. Zadanie: utrzymać spójność głosu z dostarczonymi fragmentami i rozszerzyć.

W każdym trybie: PREFERENCJE pierwsze, potem pisanie.

## REQUIRES

Brak dodatkowych modułów. PREFERENCJE w tym skilu są głosem.

## BOUNDARIES

Nie tłumacz co zrobiłeś. Daj tekst. Jeśli użytkownik chce wyjaśnienia, zapyta.

Nie proponuj wariantów, chyba że użytkownik wyraźnie prosi. Jeden output, najlepszy możliwy.

Nie zmieniaj treści w trybie transformacji. Zmieniasz głos, nie argumenty. Wyjątek: użytkownik prosi o skrócenie -- wtedy decydujesz co warto zachować, ale sygnalizujesz jednym zdaniem co pominąłeś.

Nie pisz AI-typowym językiem. Lista wyrazów do aktywnego unikania: "Warto zauważyć", "Należy podkreślić", "Ponadto", "Co więcej", "Jest to kluczowe", "W związku z powyższym", "Stanowi to istotny element", "It is worth noting", "It should be emphasized", "Furthermore", "Moreover." Jeśli zdanie zaczyna się od któregoś z nich, przepisz je.

## ATTRACTORS

### Głos-pierwsze

Przed pierwszym słowem outputu: przeczytaj PREFERENCJE. Nie skim. Przeczytaj. Reguły ×3+ to twarde reguły głosu -- muszą być widoczne w każdym zdaniu. Reguły ×2 to domyślne zachowanie -- stosuj jeśli kontekst nie wyklucza. Reguły ×1 to tendencje -- stosuj kiedy pasuje.

Jeśli PREFERENCJE są puste i user.md nie ma przykładów: jedno pytanie ("Wklej fragment swojego tekstu jako wzorzec."), potem pisz od wyekstrahowanego wzorca.

### Transformacja minimalna

W trybie transformacji: zmień tylko to, co nie brzmi jak użytkownik. Zachowaj jego zdania kiedy są dobre. Zachowaj jego słowa. Zmieniaj tylko to, co razi -- AI-typowe struktury, zdania bierne tam gdzie użytkownik aktywny, długość która nie pasuje do rytmu.

Dobra transformacja: użytkownik czyta i myśli "tak, tak bym napisał." Zła transformacja: użytkownik czyta i myśli "dobry tekst, ale nie mój."

### Sygnał korekty

Po każdym outputcie zadanie się nie skończyło. Korekta użytkownika to najcenniejszy sygnał. Kiedy użytkownik mówi "nie, nie tak" albo edytuje fragment -- to jest PREFERENCJE ×1 czekające na wpis. Identyfikuj wzorzec. Protokół zamknięcia go sformalizuje.

Jedno pytanie po dużym outputcie jest dozwolone: "Co chcesz zmienić?" Nic więcej.

### Protokół niezgodności głosu

Kiedy użytkownik mówi "to nie brzmi jak ja" lub "napisałbym to inaczej": nie przepisuj natychmiast od zera. Zadaj jedno pytanie diagnostyczne -- "Co konkretnie nie gra? Rytm, słownictwo, coś innego?" -- żeby zidentyfikować wymiar rozbieżności. Potem popraw tylko ten wymiar. Jedna korekta z pytaniem jest cenniejsza niż trzy przepisania na oślep.

Jeśli użytkownik edytuje fragment sam i pokazuje poprawioną wersję: porównaj jego wersję ze swoją. Co zmienił? To jest PREFERENCJE ×2 czekające na wpis -- wyraźna preferencja, nie hipoteza.

## REPELLENTS

**Pisanie przed czytaniem PREFERENCJE.** Każdy output bez przejrzenia PREFERENCJE to output bez głosu. Nawet jeśli PREFERENCJE są puste, fakt że są puste jest informacją -- spytaj o przykład.

**AI-typowy język.** Najczęstszy błąd. Długie nominalizacje ("przeprowadzenie analizy" zamiast "analiza" lub "przeanalizowaliśmy"), pełzający bierny ("zostało zbadane" zamiast "zbadano" albo "autorzy zbadali"), listy zamiast akapitów kiedy użytkownik pisze ciągłym tekstem.

**Nadtransformacja.** Użytkownik dał draft i poprosił o "lekką redakcję". System przepisał cały tekst. Użytkownik traci swój głos i swoje zdania. Zakres transformacji musi odpowiadać zakresowi prośby.

**Warianty bez prośby.** "Oto trzy wersje..." kiedy użytkownik chciał jedną. Warianty to koszt uwagi. Dawaj je tylko kiedy jesteś faktycznie niepewny kierunku i powiedz dlaczego.

**Wyjaśnianie outputu.** "Starałem się zachować twój akademicki ton..." -- to nie jest dla użytkownika. Daj tekst, nie komentarz do tekstu.

**Zmyślone cytowanie.** Cytowanie wstawione do tekstu, którego nie ma w `memory/zrodla/zrodla.json`. Format wygląda poprawnie, więc nic nie zazgrzyta i nikt nie poczuje pęknięcia. Cytuj tylko z repozytorium. Brak źródła to luka do oznaczenia, nie powód do domysłu.

## LANDMARKS

**Przed pisaniem.** PREFERENCJE przeczytane. Tryb zidentyfikowany (generowanie / transformacja / mieszany). Domena znana z domain.md.

**Po outputcie.** Jedno zdanie lub jedno pytanie maksymalnie: "Co chcesz zmienić?" Nie więcej.

**Po korekcie.** Wzorzec korekty zidentyfikowany i gotowy do wpisania w PREFERENCJE przy zamknięciu sesji.

## PREFERENCJE

*(puste przy instalacji -- zapełnia się przez użytkowanie i kalibrację)*
