---
name: skill_pomoc
description: >
  Pokazuje, co system potrafi. Czyta opisy wszystkich skilli obecnych w
  systemie i wypisuje możliwości prostym językiem. Użyj gdy użytkownik pyta
  co system umie, prosi o pomoc, menu, lub nie wie od czego zacząć. Trigger
  phrases: "co potrafisz", "co umiesz", "co system robi", "pomoc", "menu",
  "od czego zacząć", "jakie masz funkcje", "help", "what can you do".
tags: [pomoc, menu, przewodnik, możliwości]
---

# SKILL: Pomoc

[PRE-FLIGHT: Nie wypisuj możliwości z pamięci. Wylistuj pliki w `PROCEDURES/skills/` i `PROCEDURES/pills/`, przeczytaj nagłówek `description` każdego. Menu buduje się z tego, co faktycznie jest w systemie, więc nie zdezaktualizuje się, gdy dojdą nowe skille.]

## CEL
Odpowiadasz ZAWSZE po polsku. Pokazujesz użytkownikowi, co system potrafi, prostym językiem. Bez żargonu systemowego, bez nazw plików, bez wag i protokołów.

## WEJŚCIE
Pytanie o możliwości systemu ("co potrafisz", "pomoc", "menu"). Brak innych danych.

## PROCEDURA
1. Wylistuj skille w `PROCEDURES/skills/` i pigułki w `PROCEDURES/pills/`.
2. Dla każdego przeczytaj `description` z nagłówka.
3. Pogrupuj możliwości po tym, co użytkownik chce zrobić: konfiguracja, pisanie, źródła i literatura, myślenie i dyskusja, budowa nowych narzędzi, zamknięcie sesji.
4. Wypisz każdą możliwość jednym zdaniem po ludzku, z naturalnym przykładem frazy do powiedzenia. Nie cytuj trigger phrases technicznie.
5. Jeśli system jest świeżo zainstalowany (domain.md i user.md puste), zacznij od wskazania konfiguracji: pill_onboarding, potem pill_kalibracja.

## WYJŚCIE
Krótkie menu w rozmowie. Format: nagłówek grupy, pod nim jedno zdanie na możliwość z przykładem (np. "Pisanie: powiedz 'napisz wstęp do...' a napiszę w twoim głosie"). Nie plik. Na końcu jedno zdanie: "Powiedz, czego potrzebujesz."

## ANTY-WZORCE (czego NIE robić)
- Nie wypisuj możliwości z pamięci. Czytaj aktualne opisy skilli.
- Nie pokazuj wewnętrznych nazw, wag, protokołów ani struktury plików. To menu dla użytkownika, nie mapa systemu.
- Nie rób z tego długiej listy wszystkiego. Pogrupuj, skróć, pokaż drogę.

## PREFERENCJE
*(puste przy instalacji -- zapełnia się przez użytkowanie i kalibrację)*
