---
name: pill_kalibracja
type: pill
description: >
  Jednorazowa kalibracja głosu. Użytkownik wkleja 2-3 swoje teksty,
  system ekstrahuje wzorce stylistyczne i zapisuje je jako wstępne
  PREFERENCJE w skill_pisz.md. Po użyciu pigułka trafia do trash.
  Trigger phrases: "skalibruj system", "naucz się mojego stylu",
  "wklej moje teksty", "kalibracja głosu", "zacznijmy od moich tekstów",
  "przeczytaj moje pisanie", "naucz się jak piszę."
tags: [kalibracja, głos, styl, jednorazowe, onboarding]
---

# PIGUŁKA: Kalibracja Głosu

*Uruchom tę pigułkę raz, na początku pracy z systemem. Po kalibracji pigułka trafia do trash.*

## CEL

Zanim system nauczy się twojego głosu przez sesje, możemy zacząć od twoich tekstów. Wklej 2-3 fragmenty tego co napisałeś -- artykuły, rozdziały, maile, cokolwiek. System przejrzy je i wyekstrahuje wzorce, które staną się punktem startowym dla skill_pisz.

Im bardziej reprezentatywne teksty, tym lepszy start. Nie wybieraj "najlepszych" -- wybierz takie, które są typowe dla ciebie.

## PROCEDURA

### Krok 1: Pobierz teksty

Powiedz użytkownikowi:

"Wklej 2-3 fragmenty swoich tekstów. Każdy powinien mieć co najmniej 100 słów. Możesz wkleić je jeden po drugim i napisz 'gotowe' kiedy skończysz."

Czekaj. Nie ponaglaj. Użytkownik może potrzebować chwili na wybranie fragmentów.

### Krok 2: Analiza

Po otrzymaniu tekstów, przeanalizuj je pod kątem następujących wymiarów. Każdy wymiar przekształcasz w potencjalną regułę PREFERENCJE.

**Rytm zdań.**
Jaka jest średnia długość zdania? Czy zdania mają podobną długość czy są zróżnicowane? Czy użytkownik wstawia krótkie zdania dla rytmu? Czy dominują zdania złożone czy proste?

**Głos gramatyczny.**
Czy preferuje zdania aktywne czy bierne? Jak często pojawia się strona bierna i w jakich kontekstach (unikanie, konwencja, brak alternatywy)?

**Podmiot.**
Pierwsza osoba (ja/my), trzecia osoba (autorzy, badacze, wyniki), czy bezosobowe (zbadano, wykazano)? Czy jest spójny?

**Nominalizacje.**
Czy preferuje rzeczowniki odczasownikowe ("przeprowadzenie analizy", "dokonanie pomiaru") czy czasowniki ("analiza", "pomiar", "zmierzono")?

**Metatekst.**
Czy używa zdań metatekstowych na początku sekcji ("W niniejszym rozdziale...", "Celem tej sekcji jest...")? Czy zaczyna od meritum bez zapowiedzi?

**Przejścia.**
Jak przechodzi między tematami? Spójniki metatekstowe ("Ponadto", "Co więcej", "Natomiast") czy logika ostatniego zdania akapitu? Czy używa zdań podsumowujących na końcu akapitów?

**Otwieranie akapitów.**
Od tezy? Od kontekstu? Od danych? Od pytania?

**Charakterystyczne elementy.**
Co jest najbardziej rozpoznawalne w jego piśmie? Może to być cokolwiek: specyficzny rytm, charakterystyczne wyrażenia, sposób budowania argumentu, ulubione słowa łącznikowe.

### Krok 3: Pokaż wyniki

Podsumuj analizę użytkownikowi w normalnym języku, bez żargonu systemowego. Konkretnie: nie "preferencja głosu aktywnego" ale "piszesz aktywnie -- 'zbadaliśmy' zamiast 'zostało zbadane'."

Przykładowy format odpowiedzi:

"Z twoich tekstów widzę kilka wzorców. [Wymień 4-6 konkretnych obserwacji]. Czy to brzmi jak ty? Co chcesz dodać lub poprawić?"

Daj użytkownikowi możliwość korekty. Jeśli powie "tak, to ja" -- przejdź do kroku 4. Jeśli powie "nie do końca" -- dopytaj o co chodzi i dostosuj analizę.

### Krok 4: Wpisz PREFERENCJE

Na podstawie potwierdzonej analizy, wpisz wstępne reguły do sekcji PREFERENCJE w `PROCEDURES/skills/skill_pisz.md`.

Format wpisów:
```
- [konkretna reguła opisująca wzorzec głosu] ×[waga]
```

Wagi startowe:
- ×2 dla wzorców wyraźnych i spójnych przez całe próbki
- ×1 dla wzorców słabszych lub obecnych tylko w części tekstów
- Nie dawaj ×3+ na starcie -- te wagi zarabia się przez powtórzone potwierdzenia w sesjach

Dobre wpisy są konkretne i operacyjne. Przykłady właściwych wpisów:
- `Zdania aktywne: "zbadano" → "autorzy zbadali" lub "zbadaliśmy" ×2`
- `Akapity zaczynają się od tezy, nie od kontekstu ×2`
- `Krótkie zdanie (poniżej 10 słów) co 3-4 zdania dla rytmu ×1`
- `Unikaj spójników metatekstowych (Ponadto, Należy zauważyć) -- przejścia przez logikę zdania ×2`
- `Pierwsza osoba mnoga (my/our/we) jako podmiot ×1`

Nie dawaj więcej niż 8-10 wpisów na starcie. 5-8 dobrych reguł jest lepsze niż 15 słabych.

Po wpisaniu: pokaż użytkownikowi listę wpisanych reguł i zapytaj "Czy coś brakuje albo chcesz zmienić?"

### Krok 5: Zamknij pigułkę

Powiedz użytkownikowi: "Kalibracja gotowa. System zna teraz twój punkt startowy. Im więcej piszesz i poprawiasz, tym lepiej dopasowuje się do twojego głosu."

Przenieś plik pigułki do `trash/`.

## ZASADY

1. Nie oceniaj tekstów użytkownika. Nie komentuj czy są dobre czy złe. Ekstrahuj wzorzec, nie wystawiaj recenzji.
2. Bądź konkretny w analizie. "Piszesz krótko" to za mało. "Zdania mają średnio 15-20 słów, co 3-4 wstawiasz zdanie poniżej 10 słów" to konkret.
3. Daj użytkownikowi czas na weryfikację wyników przed wpisaniem PREFERENCJE. Zła kalibracja jest gorsza niż brak kalibracji.
4. Nie przesadzaj z liczbą wpisów. 5-8 dobrych PREFERENCJE na starcie jest lepsze niż 20 słabych.
5. Po kalibracji pigułka trafia do trash.

---
*Pigułka jednorazowa | WrAIdesk | v1.0*
