---
name: pill_onboarding
type: pill
description: >
  Guided setup of domain.md and user.md through conversation. Asks about
  writing context, audience, conventions, and personal writing style.
  Writes both files on completion. One-time installation pill -- after use,
  moves to trash. Trigger phrases: "skonfiguruj system", "uzupełnij profil",
  "wypełnij domain.md", "wypełnij user.md", "ustaw system", "zacznijmy od
  konfiguracji", "onboarding", "pierwsze kroki", "setup", "skonfiguruj mnie",
  "jak zacząć", "skąd zacząć".
tags: [onboarding, konfiguracja, domain, user, jednorazowe, setup, instalacja]
---

# PIGUŁKA: Konfiguracja Systemu

*Uruchom tę pigułkę raz, na początku pracy z systemem. Wypełnia domain.md
i user.md przez rozmowę. Po zakończeniu pigułka trafia do trash.*

## CEL

Dwa pliki definiują kontekst pisania: `domain.md` (dziedzina, odbiorcy,
konwencje) i `user.md` (profil głosu piszącego). Bez nich system pisze
w próżni -- wie jak pisać, ale nie wie dla kogo ani w jakim stylu.

Ta pigułka wypełnia oba przez rozmowę. Pięć rund pytań. Dziesięć minut.
Dwa gotowe pliki.

## PROCEDURA

### Krok 0: Sprawdź stan plików

Zanim zaczniesz pytać: przejrzyj `constitutional_files/domain.md`
i `constitutional_files/user.md`.

Jeśli któryś ma już wpisy pod nagłówkami -- zacznij od komentarza:
"Widzę, że [sekcja] jest już wypełniona. Zaczynam od brakujących części."

Jeśli oba są puste -- przejdź bezpośrednio do Kroku 1.

### Krok 1: Otwarcie

Powiedz użytkownikowi:

"Zanim zaczniesz pisać z systemem, potrzebuję zrozumieć twój kontekst.
Pięć rund pytań, potem wypełniam oba pliki konfiguracyjne.

Pierwsze: czym się zajmujesz i co piszesz? Dziedzina, typ tekstów --
artykuły naukowe, raporty, eseje, dokumenty techniczne, cokolwiek."

Czekaj na odpowiedź. Jeśli jest zbyt ogólna ("piszę po polsku"), dopytaj:
"W jakiej konkretnie dziedzinie? Jaka subdyscyplina lub typ pracy?"

### Krok 2: Kontekst i rola

Po odpowiedzi na pytanie o dziedzinę, zadaj dwa pytania razem:

"Kto czyta twoje teksty? I w jakim języku głównie piszesz -- jeśli
w kilku, który jest priorytetowy?"

Zanotuj: odbiorców (recenzenci, studenci, szeroka publiczność, specjaliści
branżowi, inne) i język główny. Jeśli użytkownik podaje kilka języków --
dopytaj o priorytety.

Jeśli przy opisie dziedziny lub odbiorców pojawia się jasna rola lub
instytucja (np. "jestem doktorantem na UAM", "pracuję jako UX writer
w korporacji") -- zanotuj. Trafi do "Kim jestem" w user.md. Jeśli nie
pojawia się naturalnie, nie pytaj osobno -- rola wyłania się z kontekstu.

### Krok 3: Konwencje formalne

"Czy stosujesz konkretny styl cytowań albo piszesz do określonych
czasopism lub wydawnictw? (APA, Vancouver, Chicago, wymagania redakcyjne,
konkretne tytuły -- cokolwiek istotnego.)"

Czekaj. Potem:

"Czy są pojęcia kluczowe w twojej dziedzinie, których system powinien
używać i rozumieć poprawnie -- i których nie powinien zastępować
synonimami?"

Jeśli użytkownik mówi "nie mam szczególnych wymagań" -- zanotuj jako brak
specyficznych konwencji. Jeśli wymienia pojęcia -- zbierz je z definicjami
roboczymi jeśli podaje.

Dodaj na końcu tej rundy: "Czy jest coś, czego chcesz unikać w tekstach?
Nadużywane zwroty w twojej dziedzinie, irytujące konwencje, cokolwiek."

### Krok 4: Styl pisania

"Teraz twoje pisanie.

Jak wygląda twój styl? Bezpośredni czy opisowy, oszczędny czy rozbudowany,
formalny czy swobodny, aktywny czy pasywny -- cokolwiek jest trafne."

Czekaj. Potem:

"Jak zazwyczaj zaczynasz akapit lub sekcję? Od głównej tezy, od
szerokiego kontekstu, od pytania, od danych?"

Jeśli odpowiedź jest lakoniczna ("normalnie"), pomóż konkretyzacją:
"Wyobraź sobie ostatni tekst, który skończyłeś/skończyłaś. Jak zaczynał
się pierwszy akapit po nagłówku -- od tezy czy od wprowadzenia?"

Nie używaj form rodzajowych w zdaniach kiedy możesz ich uniknąć.
Zamiast "napisałeś/napisałaś" -- "twój ostatni tekst", "tekst który
masz", "ostatnia sekcja którą pisałeś/aś" (ta forma jest dopuszczalna
jeśli konieczna).

### Krok 5: Głos i niechęci

Dwa pytania razem:

"Jak przechodzisz między tematami? Spójniki metatekstowe (Ponadto,
Natomiast, Należy zauważyć), logika ostatniego zdania akapitu, czy
explicite zapowiadasz przejście?

I -- co cię irytuje w cudzych tekstach naukowych lub tekstach
generowanych przez AI? Styl, wyrażenia, struktury -- cokolwiek."

Jeśli użytkownik nic nie wymienia w kwestii niechęci, zasugeruj:
"A co z listami tam gdzie można pisać ciągłym tekstem? Zdaniami
biernymi? Nominalizacjami ('przeprowadzenie analizy' zamiast
'przeanalizowaliśmy')?"

### Krok 6: Pokaż wyniki

Podsumuj zebrany materiał użytkownikowi w normalnym języku -- jako
opis, nie listę punktów (lista jest dopuszczalna tylko dla terminologii).

Format podsumowania:

"Z naszej rozmowy wyłania się taki obraz:

*Dziedzina i odbiorcy:* [opis -- konkretny, nie abstrakcyjny]
*Konwencje formalne:* [opis lub 'brak specyficznych wymagań']
*Terminologia kluczowa:* [lista lub 'nie podano szczegółów']
*Czego unikać:* [opis lub 'brak dodatkowych wskazówek']
*Język:* [język / priorytety jeśli kilka]

*Styl pisania:* [opis]
*Otwieranie akapitów:* [opis]
*Przejścia:* [opis]
*Czego nie lubisz:* [opis]

Czy coś jest niedokładne albo chcesz coś dodać?"

Daj użytkownikowi możliwość korekty. Jeśli zaakceptuje -- przejdź do
Kroku 7. Jeśli powie "nie do końca" -- dopytaj o co chodzi, popraw,
powtórz podsumowanie.

### Krok 7: Zapisz pliki

Na podstawie potwierdzonego materiału, zapisz zawartość do obu plików.

**Zasady zapisu:**
- Używaj konkretnego języka użytkownika, nie przeformułowuj na ogólniki.
  Jeśli powiedział "piszę artykuły do Nature i Science" -- wpisz to,
  nie "pisanie do prestiżowych czasopism naukowych."
- Sekcje bez informacji pozostaw puste z komentarzem *(nie podano)* albo
  zostaw je z oryginalnym pytajnikiem szablonu.
- Sekcja "Mój słownik" w user.md -- wypełnij tylko jeśli użytkownik
  wspomniał charakterystyczne słowa lub zwroty. Jeśli nie wspomniał --
  pozostaw pustą bez komentarza.

**Zapisuj do `constitutional_files/domain.md`:**
- Czym się zajmuję
- Dla kogo piszę
- Konwencje formalne
- Terminologia kluczowa
- Czego unikać w tej dziedzinie
- Język główny

**Zapisuj do `constitutional_files/user.md` (profil stały):**
- Kim jestem *(z roli/instytucji która wyłoniła się z rozmowy;
  jeśli nie wyłoniła się -- zostaw pustą)*
- Jak piszę ogólnie *(ogólny charakter, jedno-dwa zdania)*
- Mój słownik *(jeśli dotyczy)*
- Czego nie lubię
- Przykładowe fragmenty -- wpisz:
  *(Puste po konfiguracji. Uruchom pill_kalibracja.md żeby wypełnić
  tę sekcję -- system ekstrahuje wzorce głosu z twoich tekstów.)*

Operacyjnych reguł głosu (rytm zdań, otwieranie akapitów, przejścia) NIE
zapisujesz do user.md. Te zbiera pill_kalibracja do PREFERENCJE w skill_pisz.

Po zapisaniu: wymień krótko które sekcje zostały wypełnione, które
pozostały puste i dlaczego.

### Krok 8: Zaktualizuj dashboard

Otwórz `constitutional_files/dashboard.md`. Zaktualizuj:
- Datę ostatniej aktualizacji
- Sekcję "Otwarte wątki": odznacz zadanie "Wypełnij domain.md przed
  pierwszą sesją pisania" jako wykonane (usuń lub przekreśl)
- Jeśli pill_kalibracja jeszcze nie była uruchomiona -- pozostaw
  "Uruchom pill_kalibracja.md" jako otwarte

### Krok 9: Zamknij pigułkę

Powiedz użytkownikowi:

"Konfiguracja gotowa. System zna teraz twój kontekst i podstawowy profil
głosu.

Opcjonalny krok: uruchom pill_kalibracja.md -- wklej 2-3 fragmenty
swoich tekstów, a system wyekstrahuje wzorce i zbuduje punkt startowy
dla PREFERENCJE w skill_pisz.md. Bez kalibracji system będzie się
dopasowywać stopniowo przez sesje -- kalibracja tylko przyspiesza
ten proces.

Możesz zacząć pisać od razu. A jeśli chcesz zobaczyć wszystko, co system potrafi, powiedz w dowolnym momencie: co potrafisz."

Przenieś plik pigułki do `trash/`.

## ZASADY

1. Nie zadawaj więcej niż 2-3 pytania naraz. Jeśli masz więcej --
   poczekaj na odpowiedź.
2. Nie oceniaj wyborów użytkownika. Każdy kontekst pisania jest
   równie dobry.
3. Jeśli odpowiedź jest zbyt ogólna -- jedno dopytanie o konkret.
   Nie przepytuj w kółko.
4. Wpisuj do plików to, co powiedział użytkownik. Konkret jest
   lepszy niż ogólnik przeformułowany na styl szablonu.
5. Sekcja "Przykładowe fragmenty" w user.md pozostaje pusta po tej
   pigułce. Należy do pill_kalibracja -- nie zastępuj jej.
6. dashboard.md musi być zaktualizowany -- to część zamknięcia.
7. Po zakończeniu pigułka trafia do trash.

---
*Pigułka jednorazowa | WrAIdesk | v1.0*
