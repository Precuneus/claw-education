# DASHBOARD
Aktualizacja: [data instalacji]

## Aktywne skille
- skill_pisz: generuje nowy tekst i transformuje istniejące drafty w głosie użytkownika
- skill_koniec_rozmowy: zamyka sesję, zbiera feedback, aktualizuje PREFERENCJE i dashboard

## Aktywne projekty
(brak)

## Ostatnia sesja
System zainstalowany. Brak wcześniejszych sesji.

## Otwarte wątki
- [ ] Uruchom pill_onboarding.md (wypełnia domain.md i user.md przez rozmowę)
- [ ] Uruchom pill_kalibracja.md (kalibracja głosu -- wklej 2-3 swoje teksty)
