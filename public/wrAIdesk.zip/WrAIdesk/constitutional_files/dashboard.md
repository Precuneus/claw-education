# DASHBOARD
Aktualizacja: 2026-05-28

## Aktywne skille
- skill_pisz: generuje nowy tekst i transformuje istniejące drafty w głosie użytkownika
- skill_koniec_rozmowy: zamyka sesję, zbiera feedback, aktualizuje PREFERENCJE i dashboard
- skill_szukaj_literatury: szuka publikacji w sieci i dopisuje je do repozytorium źródeł (zrodla.json)
- skill_dyskusja: eksploruje hipotezy i sprawdza je względem źródeł (tryb myślenia, nie pisania)
- skill_pomoc: pokazuje możliwości systemu (menu czytane z opisów skilli)

## Aktywne projekty
(brak)

## Ostatnia sesja
System zainstalowany. Brak wcześniejszych sesji.

## Otwarte wątki
- [ ] Uruchom pill_onboarding.md (wypełnia domain.md i user.md przez rozmowę)
- [ ] Uruchom pill_kalibracja.md (kalibracja głosu -- wklej 2-3 swoje teksty)
