# OPERATIONS

Operacje są teraz częścią instrukcji. Zobacz `system_prompt.md` (sekcje: Rozruch, Lokalizacja plików, Weryfikacja, Źródła i cytowania, Pamięć, Skille, Pigułki, Zamykanie sesji, Współodkrywanie, Metodologia, Dashboard, User.md, Konwencje narzędziowe).
