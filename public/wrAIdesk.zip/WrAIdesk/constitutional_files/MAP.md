# MAPA SYSTEMU: WrAIdesk

```
WrAIdesk/
├── constitutional_files/         # Pliki systemowe (ładowane na starcie każdej sesji)
│   ├── system_prompt.md          # INSTRUKCJE: soul + architektura + rozruch + operacje + przegląd skilli/pigułek
│   ├── operations.md             # wskaźnik (operacje scalone do system_prompt.md)
│   ├── domain.md                 # Dziedzina, konwencje formalne, terminologia (wypełnia użytkownik)
│   ├── user.md                   # Profil głosu użytkownika (buduje się z czasem)
│   ├── dashboard.md              # Aktualny stan systemu (aktualizowany przy zamknięciu)
│   └── MAP.md                    # Ten plik
├── PROCEDURES/                   # Wszystkie procedury: skille, pigułki
│   ├── skills/                   # Skille (procedury do powtarzalnych zadań)
│   │   ├── skill_pisz.md         # Generowanie i transformacja tekstu w głosie użytkownika
│   │   ├── skill_koniec_rozmowy.md  # Protokół zamknięcia sesji
│   │   ├── skill_szukaj_literatury.md  # Szuka publikacji w sieci i dopisuje do repozytorium źródeł
│   │   ├── skill_dyskusja.md     # Eksploruje hipotezy i sprawdza je względem źródeł (tryb myślenia)
│   │   └── skill_pomoc.md        # Pokazuje możliwości systemu (menu z opisów skilli)
│   └── pills/                    # onboarding/kalibracja jednorazowe; skill_builder to staly pipeline
│       ├── pill_onboarding.md    # Konfiguracja domain.md i user.md przez rozmowę (uruchom raz)
│       ├── pill_kalibracja.md    # Kalibracja głosu z tekstów użytkownika (uruchom raz)
│       ├── pill_skill_builder_phase_01_coarse.md   # builder skilli: 3-fazowy STALY pipeline (NIE do trash)
│       ├── pill_skill_builder_phase_02_detailed.md
│       └── pill_skill_builder_phase_03_verification.md
├── templates/                    # Szablony do kopiowania (nie przenoś, kopiuj)
│   └── dashboard_projekt.md
├── memory/                       # Pamięć systemu (rośnie z czasem)
│   ├── ongoing/                  # Aktywne projekty (każdy z własnym dashboardem)
│   ├── moje_teksty/              # Teksty wygenerowane i transformowane przez skill_pisz
│   ├── zrodla/                   # Repozytorium źródeł (zrodla.json: skategoryzowane wpisy z opisem)
│   └── uncategorised/            # Pliki bez jasnej lokalizacji (porządkowane przy zamknięciu)
└── trash/                        # Kosz (zużyte pigułki, stare wersje, niepotrzebne pliki)
```

## Zasady

- Pliki generowane przez skille trafiają do swoich katalogów w `memory/` (np. `memory/moje_teksty/`), nie do katalogu głównego.
- `constitutional_files/` to rdzeń systemu. Nie edytuj ręcznie poza `user.md` i `domain.md`.
- `PROCEDURES/` zawiera wszystkie procedury. Skille są permanentne. Pigułki onboarding i kalibracja są jednorazowe (po użyciu -> trash). Pigułki skill_buildera (phase_01/02/03) to stały, wielokrotny pipeline -- nie przenoś ich do trash.
- `templates/` zawiera szablony. Kopiuj, nie przenoś.
- `memory/ongoing/` przechowuje aktywne projekty. Nowy projekt = nowy folder + dashboard (z szablonu).
- `memory/uncategorised/` to poczekalnia. Protokół zamknięcia ją porządkuje.
- `trash/` to kosz. Nie usuwane, na wypadek gdyby były potrzebne.

## Pierwsze kroki

1. Uruchom `PROCEDURES/pills/pill_onboarding.md` (wypełnia domain.md i user.md przez rozmowę)
2. Uruchom `PROCEDURES/pills/pill_kalibracja.md` (wklej 2-3 swoje teksty -- kalibracja głosu)
3. Zacznij pisać z `PROCEDURES/skills/skill_pisz.md`
