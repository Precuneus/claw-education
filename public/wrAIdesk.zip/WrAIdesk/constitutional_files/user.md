# UŻYTKOWNIK -- profil stały

*(To twój stały profil: kim jesteś i ogólny charakter twojego pisania. Operacyjne reguły głosu (rytm zdań, strona czynna, otwieranie akapitów, przejścia) nie są tutaj. Żyją w sekcji PREFERENCJE w `PROCEDURES/skills/skill_pisz.md` i uczą się przez kalibrację oraz korekty w sesjach. Tu trzymamy to, co stałe.)*

## Kim jestem

*(Twoja rola, instytucja, etap kariery -- cokolwiek jest istotne dla kontekstu pisania.)*

## Jak piszę ogólnie

*(Ogólny charakter w jednym-dwóch zdaniach: bezpośredni czy opisowy, oszczędny czy rozbudowany, formalny czy swobodny. Szczegółowe reguły operacyjne są w PREFERENCJE.)*

## Mój słownik

*(Słowa i zwroty charakterystyczne dla ciebie: ulubione wyrażenia, specyficzna terminologia, idiomy.)*

## Czego nie lubię

*(W cudzych tekstach i we własnych. Co cię irytuje w pisaniu naukowym lub pisaniu AI?)*

## Przykładowe fragmenty

*(Wklej fragmenty reprezentatywne dla ciebie. System wraca do nich jako do wzorca. Uruchom pill_kalibracja.md, żeby wyekstrahować z nich reguły do PREFERENCJE.)*
