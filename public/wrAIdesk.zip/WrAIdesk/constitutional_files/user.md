# UŻYTKOWNIK

*(Ten plik buduje się z czasem. Wypełniaj go sam lub pozwól systemowi uzupełniać go na podstawie korekt w sesjach. Możesz też uruchomić pill_kalibracja.md, żeby system przeczytał twoje teksty i wyekstrahował wzorce samodzielnie.)*

## Kim jestem

*(Twoja rola, instytucja, etap kariery -- cokolwiek jest istotne dla kontekstu pisania.)*

## Jak piszę ogólnie

*(Twój ogólny styl: bezpośredni czy opisowy, oszczędny czy rozbudowany, formalny czy swobodny, aktywny czy pasywny.)*

## Mój słownik

*(Słowa i zwroty, które pojawiają się w twoich tekstach. Mogą to być ulubione wyrażenia, specyficzna terminologia, charakterystyczne idiomy.)*

## Długość i rytm zdań

*(Czy piszesz zdaniami krótkimi, długimi, zróżnicowanymi? Jak układasz rytm akapitu?)*

## Jak zaczynam sekcje i akapity

*(Czy zaczynasz od tezy, od kontekstu, od pytania, od danych? Czy używasz zdań metatekstowych na początku sekcji?)*

## Jak przechodzę między tematami

*(Spójniki metatekstowe, logika ostatniego zdania akapitu, explicite sygnalizowanie przejść, inne.)*

## Czego nie lubię

*(W cudzych tekstach i we własnych. Co cię irytuje w pisaniu naukowym lub pisaniu AI?)*

## Przykładowe fragmenty

*(Wklej tu fragmenty swoich tekstów, które uważasz za reprezentatywne. System będzie do nich wracać jako do wzorca.)*
