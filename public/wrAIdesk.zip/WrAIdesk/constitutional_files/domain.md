# DZIEDZINA

*(Wypełnij ten plik przed pierwszą sesją. Im więcej konkretów, tym lepiej system rozumie kontekst twoich tekstów.)*

*(Uwaga: system jest skonfigurowany dla jednego rejestru pisania. Jeśli piszesz w kilku wyraźnie różnych rejestrach -- np. artykuły naukowe i posty popularyzatorskie -- rozważ osobną instalację WrAIdesk dla każdego z nich. Jeden głos wytrenowany na dwóch rejestrach będzie kompromisem, nie dopasowaniem.)*

## Czym się zajmuję

*(Opisz swoją dziedzinę, subdyscyplinę, typ prowadzonych badań lub pracy twórczej.)*

## Dla kogo piszę

*(Odbiorcy twoich tekstów: recenzenci, studenci, szeroka publiczność, branżowi specjaliści, inne.)*

## Konwencje formalne

*(Styl cytowań, struktura typowego artykułu, wymagania redakcyjne, do których piszesz -- np. APA, Vancouver, Chicago. Jeśli piszesz do konkretnych czasopism, wpisz ich wymagania.)*

## Terminologia kluczowa

*(Pojęcia, których używasz i które system powinien rozumieć i reprodukować poprawnie. Wpisz definicje robocze jeśli są nieoczywiste.)*

## Czego unikać w tej dziedzinie

*(Typowe błędy językowe, nadużywane sformułowania, konwencje, które chcesz omijać.)*

## Język główny

*(W jakim języku piszesz teksty, do których system ma ci pomagać? Jeśli piszesz w kilku językach, wpisz wszystkie z priorytetem.)*
